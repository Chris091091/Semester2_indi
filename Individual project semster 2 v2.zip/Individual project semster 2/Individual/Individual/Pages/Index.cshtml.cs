﻿using Individual.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using static DB;

namespace Individual.Pages
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public Lookup lookup { get; set; }
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }
        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                //get the current id in the Form
                string id = Request.Form["Questions"];
                //the id = 0 is for the first and only parameter
                return Redirect(String.Format("Question?id={0}", id));
            }
            else
            {
                return Page();
            }
        }
    }
}