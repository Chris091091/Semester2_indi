using Individual.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static DB;

namespace Individual.Pages
{
    public class QuestionModel : PageModel
    {
        [BindProperty]
        public DB.Question question { get; set; }
        public void OnGet(int id)
        {
            question = DB.Question.get(id);
        }
    }
}
