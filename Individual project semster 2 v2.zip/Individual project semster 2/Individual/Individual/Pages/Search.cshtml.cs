using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Week3_demo.Models;

namespace Individual.Pages
{
    public class SearchModel : PageModel
    {
        [BindProperty]
        //Search.cs is in models
        public Search Search { get; set; }
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                string message = "Searching";

                ViewData["Message"] = message;
                //should in the future return to a modified index page
                return Page();
            }
            else
            {
                ViewData["Message"] = "Please enter a data fields";
                return Page();
            }
        }
    }
}
