using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Individual.Pages.Shared
{
    public class _Layout1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
