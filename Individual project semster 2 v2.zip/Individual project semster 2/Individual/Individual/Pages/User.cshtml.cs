using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Week3_demo.Models;

namespace Individual.Pages
{
    public class UserModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
