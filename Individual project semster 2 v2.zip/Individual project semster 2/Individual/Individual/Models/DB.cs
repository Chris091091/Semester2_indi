﻿using Microsoft.Data.SqlClient;
using NuGet.Protocol.Plugins;

    public static partial class DB
    {
        internal static SqlConnection Con()
        {
            //Easy to edit 
            SqlConnection con = new SqlConnection(@"Server=mssqlstud.fhict.local;Database=dbi500550_test;User Id=dbi500550_test;Password=Student;TrustServerCertificate=True;");
            con.Open();
            return con;
        }

    }
