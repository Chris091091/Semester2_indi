﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Domains
{
    public class Response : DAL.IRecord
    {
        public string? ID_Response;
        public string? Title;
        public string? Text;
        public string? ID_Question;
        public string? Timestamp;
        public string? ID_Account;
        public int Votes = 0;

        public Response()
        {

        }

        public void set(SqlDataReader record)
        {
            ID_Response = record.GetString(record.GetOrdinal("ID_Response"));
            Title = record.GetString(record.GetOrdinal("Title"));
            Text = record.GetString(record.GetOrdinal("Text"));
            ID_Question = record.GetString(record.GetOrdinal("ID_Question"));
            Timestamp = record.GetDateTime(record.GetOrdinal("Timestamp")).ToString();
            ID_Account = record.GetString(record.GetOrdinal("ID_Account"));
        }
        public void get(SqlCommand record)
        {
            record.Parameters.AddWithValue("@ID_Response", this.ID_Response);
            record.Parameters.AddWithValue("@Title", this.Title);
            record.Parameters.AddWithValue("@Text", this.Text);
            record.Parameters.AddWithValue("@ID_Question", this.ID_Question);
            record.Parameters.AddWithValue("@Timestamp", this.Timestamp);
            record.Parameters.AddWithValue("@ID_Account", this.ID_Account);
        }
    }
}
