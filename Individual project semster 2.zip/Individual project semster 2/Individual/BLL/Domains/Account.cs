﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace BLL.Domains
{
    public class Account : DAL.IRecord
    {
        public string? Username;
        public string? Password;
        public string? Picture;
        public bool Is_Admin;
        public bool Is_Blocked;

        public Account()
        {
        }

        public void set(SqlDataReader record)
        {
            Username = record.GetString(record.GetOrdinal("Username"));
            Password = record.GetString(record.GetOrdinal("Password"));
            //Picture = record.GetString(record.GetOrdinal("Picture"));
            Is_Admin = record.GetBoolean(record.GetOrdinal("Is_Admin"));
            Is_Blocked = record.GetBoolean(record.GetOrdinal("Is_Blocked"));
        }
        public void get(SqlCommand record)
        {
            record.Parameters.AddWithValue("@Username", this.Username);
            record.Parameters.AddWithValue("@Password", this.Password);
            //record.Parameters.AddWithValue("@Picture", this.Picture);
            if (Is_Admin)
            {
                record.Parameters.AddWithValue("@Is_Admin", 0);
            }
            else
            {
                record.Parameters.AddWithValue("@Is_Admin", 1);
            }
            record.Parameters.AddWithValue("@Is_Blocked", this.Is_Blocked);
        }
    }
}
