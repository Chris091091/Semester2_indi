﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Domains
{
    public class Question : DAL.IRecord
    {
        public string? ID;
        public string? Title;
        public string? Text;
        public string? Timestamp;
        public string? ID_Account;
        public int Votes = 0;
        public int Answers = 0;

        public Question()
        {

        }

        //public Question(string? ID, string? Title, string? Text, string? Timestamp, string? ID_Account)
        //{
        //    this.ID = ID;
        //    this.Title = Title;
        //    this.Text = Text;
        //    this.Timestamp = Timestamp;
        //    this.ID_Account = ID_Account;
        //}
        //public Question(DAL.Question src)
        //{
        //    ID = src.ID;
        //    Title = src.Title;
        //    Text = src.Text;
        //    Timestamp = src.Timestamp;
        //    ID_Account = src.ID_Account;
        //}
        public void set(SqlDataReader record)
        {
            ID = record.GetString(record.GetOrdinal("ID"));
            Title = record.GetString(record.GetOrdinal("Title"));
            Text = record.GetString(record.GetOrdinal("Text"));
            Timestamp = record.GetDateTime(record.GetOrdinal("Timestamp")).ToString();
            ID_Account = record.GetString(record.GetOrdinal("ID_Account"));
        }

        public void get(SqlCommand record)
        {
            record.Parameters.AddWithValue("@ID", this.ID);
            record.Parameters.AddWithValue("@Title", this.Title);
            record.Parameters.AddWithValue("@Text", this.Text);
            record.Parameters.AddWithValue("@Timestamp", this.Timestamp);
            record.Parameters.AddWithValue("@ID_Account", this.ID_Account);
        }


    }
}
