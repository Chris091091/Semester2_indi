﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BLL.Domains;


namespace BLL.Managers
{
    public static class ResponseManager 
    {

        internal class ResponseList : List<Response>, DAL.IRecordList
        {
            public DAL.IRecord AddIRecord()
            {
                Response response = new Response();
                this.Add(response);
                return response;
            }
        }
        public static Response? get(string id)
        {
            Response response = new Response();
            return DAL.Response.get(id, response) ? response : null; ;
        }

        public static List<Response> getAll(string question_id)
        {
            ResponseList list = new ResponseList();
            DAL.Response.getAll(question_id, list);
            return list;
        }

        public static bool add(string question_id, string title, string text, string ID_Account)
        {
            Response response = new Response();
            response.ID_Response = Accountmanager.GetRandomID();
            response.Title = title;
            response.Text = text;
            response.ID_Question = question_id;
            response.Timestamp = Accountmanager.GetTimeStamp();
            response.ID_Account = ID_Account;
            return DAL.Response.add(response);
        }
        public static bool delete(Response response)
        {
            return DAL.Response.Delete(response);
        }

        public static bool update(Response response)
        {
            return DAL.Response.update(response);
        }
    }
}
