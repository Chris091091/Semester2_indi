﻿using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks.Dataflow;
using BLL.Domains;

namespace BLL.Managers
{
    public static class Accountmanager
    {
        //public static Account? Log_in(string Username, string password)
        //{
        //    Account account = new Account(); ;
        //    if (DAL.Account.get(Username, account) && 
        //        (account.Password == password))
        //    {
        //        return account;
        //    }
        //    return null;
        //}
        static int keySize = 16;
        static int iterations = 350000;
        static HashAlgorithmName hashAlgorithm = HashAlgorithmName.SHA512;

        public static string GetRandomID()
        {
            StringBuilder builder = new StringBuilder();
            Enumerable
               .Range(65, 26)
                .Select(e => ((char)e).ToString())
                .Concat(Enumerable.Range(97, 26).Select(e => ((char)e).ToString()))
                .Concat(Enumerable.Range(0, 10).Select(e => e.ToString()))
                .OrderBy(e => Guid.NewGuid())
                .Take(16)
                .ToList().ForEach(e => builder.Append(e));
            return builder.ToString();
        }

        public static bool add(string username, string password, bool admin, string picture)
        {
            Account account = new Account();
            account.Username = username;
            account.Password = password;
            account.Picture = picture;
            account.Is_Admin = admin;
            account.Is_Blocked = false;
            return DAL.Account.add(account);
        }

        public static bool change_password(string user, string password)
        {
            //enocding the password with hash and salt then passing it on to the database
            return DAL.Account.change_password(user, encode_password(password));
        }

        //hash and salt password
        public static string encode_password(string password)
        {
            var salt = RandomNumberGenerator.GetBytes(keySize);
            var hash = Rfc2898DeriveBytes.Pbkdf2(
                Encoding.UTF8.GetBytes(password),
                salt,
                iterations,
                hashAlgorithm,
                keySize);
            return Convert.ToHexString(salt) + "," + Convert.ToHexString(hash);
        }

        public static Account? check_password(string username, string password)
        {
            Account account = new Account(); ;
            if (!DAL.Account.get(username, account))
            {
                return null;
            }

            string[] ar = account.Password.Split(',');
            //seperating the salt and hash back into byte arrays from the database from the username
            var salt = Convert.FromHexString(ar[0]);
            //check hash is hashing the password given with the old salt
            var checkHash = Rfc2898DeriveBytes.Pbkdf2(
                Encoding.UTF8.GetBytes(password),
                salt,
                iterations,
                hashAlgorithm,
                keySize);
            string hex = Convert.ToHexString(checkHash);
            //check the hash in the database to the new hash created from the input of the password if same return true
            return (ar[1] == hex) ? account : null;
        }

        public static string GetTimeStamp()
        {
            DateTime myDateTime = DateTime.Now;
            return myDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff");
        }
    }
}