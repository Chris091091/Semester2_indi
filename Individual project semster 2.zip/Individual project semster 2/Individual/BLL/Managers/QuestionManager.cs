﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BLL.Domains;

namespace BLL.Managers
{
    public static class QuestionManager
    {
        internal class QuestionList : List<Question>, DAL.IRecordList
        {
            public DAL.IRecord AddIRecord()
            {
                Question question = new Question();
                this.Add(question);
                return question;
            }
        }

        public static Question? get(string id)
        {
            Question question = new Question();
            // the ? is for if with it returning question if true and null if false
            return DAL.Question.get(id, question) ? question : null;
        }

        public static List<Question> getAll()
        {
            QuestionList list = new QuestionList();
            DAL.Question.getAll(list);
            return list;
        }

        public static bool add(string title, string text, string ID_Account)
        {
            Question question = new Question();
            question.ID = Accountmanager.GetRandomID();
            question.Title = title;
            question.Text = text;
            question.Timestamp = Accountmanager.GetTimeStamp();
            question.ID_Account = ID_Account;
            return DAL.Question.add(question);
        }

        public static bool update(Question question)
        {
            return DAL.Question.update(question);
        }

        public static bool delete(Question question)
        {
            return DAL.Question.Delete(question);
        }
    }
}
