﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace Week3_demo.Models
{
    public class Search
    {
        public Search()
        { }
        public Search(string name, string votes)
        {
            Name = name;
            Votes = votes;
        }

        [Required]
        public string Name { get; set; }
        [Required]
        public string Votes { get; set; }


    }
}

