﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BLL.Managers;

namespace PL.Models
{
    public class BasePage : PageModel
	{
        public IActionResult OnGet()
        {
            return null;
        }

    }
}
