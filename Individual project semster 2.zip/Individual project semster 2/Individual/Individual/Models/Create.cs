﻿using Microsoft.Data.SqlClient;
using Microsoft.DotNet.Scaffolding.Shared.Messaging;
using System.Diagnostics.Metrics;
using System.Reflection;
using System.Xml.Linq;


namespace Individual.Models
{
    public class Create
    {
        public Create()
        { }
        public Create(string title, string subject)
        {
            Title = title;
            Subject = subject;
        }
        public string Title { get; set; }
        public string Subject { get; set; }
        }
    }
