using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BLL.Managers;
using BLL.Domains;

namespace PL.Pages
{
    public class Edit_QuestionModel : PageModel
    {
        [BindProperty]
        public string Title { get; set; }
        [BindProperty]
        public string Text { get; set; }

    
        public IActionResult? OnGet(string id)
        {
            var q = QuestionManager.get(id);
            if (q != null)
            {
                Title = q.Title;
                Text = q.Text;

            }
            return null;
        }

        public IActionResult OnPost(string id, string command)
        {
            var q = QuestionManager.get(id);
            if (q != null)
            {
                if (command == "Save")
                {
                    q.Title = Title;
                    q.Text = Text;
                    BLL.Managers.QuestionManager.update(q);
                    return Redirect(String.Format("Question?id={0}", id));
                }
                else if (command == "Delete")
                {
                    BLL.Managers.QuestionManager.delete(q);
                    return Redirect(String.Format("Index"));
                }
            }
            return Page();
        }
    }
}
