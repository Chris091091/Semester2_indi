using Individual.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PL.Models;
using BLL.Managers;
using BLL.Domains;
using Azure;
using System.Net;
using PL.Pages;

namespace Individual.Pages
{
    public class QuestionModel : PageModel
    {
        [BindProperty]
        public Question question { get; set; } = new Question();

        public IActionResult? OnGet(string id)
        {
            var q = QuestionManager.get(id);
            if (q != null)
            {
                question = q;
                ViewData["Id_Account"] = question.ID_Account;
                ViewData["ID_Question"] = question.ID;
                ViewData["Votes"] = question.Votes;
                ViewData["Title"] = question.Title;
                ViewData["Text"] = question.Text;
                ViewData["Current_user"] = User.FindFirst("id")?.Value;            }
            return null;
        }
    }
}
