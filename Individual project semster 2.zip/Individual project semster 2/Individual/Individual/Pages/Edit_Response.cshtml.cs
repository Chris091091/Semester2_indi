using BLL.Managers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PL.Pages
{
    public class Edit_ResponseModel : PageModel
    {
        [BindProperty]
        public string Title { get; set; }
        [BindProperty]
        public string Text { get; set; }


        public IActionResult? OnGet(string id)
        {
            var r = ResponseManager.get(id);
            if (r != null)
            {
                Title = r.Title;
                Text = r.Text;

            }
            return null;
        }
        public IActionResult OnPost(string id, string command)
        {
            var r = ResponseManager.get(id);
            if (r != null)
            {
                if (command == "Save")
                {
                    r.Title = Title;
                    r.Text = Text;
                    BLL.Managers.ResponseManager.update(r);
                    return Redirect(String.Format("Index"));
                }
                else if (command == "Delete")
                {
                    BLL.Managers.ResponseManager.delete(r);
                    return Redirect(String.Format("Index"));
                }
            }
            return Page();
        }
    }
}
