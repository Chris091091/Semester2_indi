using BLL.Managers;
using Individual.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace PL.Pages
{
    public class Add_ResponseModel : PageModel
    {
        [BindProperty]
        public String Title { get; set; }
        [BindProperty]
        public String Text { get; set; }

        public IActionResult? OnGet(string id)
        {
            BLL.Domains.Question q = BLL.Managers.QuestionManager.get(id);
            ViewData["Votes"] = q.Votes;
            ViewData["Title"] = q.Title;
            ViewData["Text"] = q.Text;
            @ViewData["ID_Question"] = id;

            return null;
        }
        //takes from the url
        public IActionResult OnPost(string id)
        {
            if (ModelState.IsValid)
            {
                string message = "The Question:  " + Title + " has been created";
                ViewData["Message"] = message;
                string ID_Account = User.FindFirst("id")?.Value;

                ResponseManager.add(id, Title, Text, ID_Account);
                return Redirect(String.Format("Question?id={0}", id));
            }
            else
            {
                ViewData["Message"] = "Please enter all data fields";
                return Page();
            }
        }
    }
}
