using BLL.Domains;
using BLL.Managers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PL.Models;
using Week3_demo.Models;

namespace Individual.Pages
{
    public class UserModel : BasePage
    {

        [BindProperty]
        public String oldpassword { get; set; }
        [BindProperty]
        public String newpassword { get; set; }
        [BindProperty]
        public String checkpassword { get; set; }
        public IActionResult OnPost()
        {
            if (newpassword != checkpassword)
            {
                ViewData["Message"] = "password and password check are not the same";
                return Page();
            }
            string username = User.FindFirst("id")?.Value;
                            
            //if (BLL.Managers.Accountmanager.check_password(username, oldpassword) == null) 
            //{
            //    ViewData["Message"] = "Invalid previous password";
            //    return Page();
            //}
            if (ModelState.IsValid)
            {
                string message = "The User:  " + newpassword + " has been created";
                ViewData["Message"] = message;

                Accountmanager.change_password(username, newpassword);
                return Redirect(String.Format("Index"));
            }
            else
            {
                ViewData["Message"] = "Please enter all data fields";
                return Page();
            }
        }
    }
}
