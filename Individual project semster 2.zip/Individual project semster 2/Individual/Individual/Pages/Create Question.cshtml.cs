using Individual.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PL.Models;
using BLL.Managers;
using System.Security.Claims;

namespace PL.Pages
{
    public class Create_QuestionModel : BasePage
    {
        [BindProperty]
        public Create create { get; set; }
        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                string message = "The Question:  " + create.Title + " has been created";
                ViewData["Message"] = message;

                //using the loginpage/current user stored in the cookie()

                string ID_Account = User.FindFirst("id")?.Value;

                QuestionManager.add(create.Title, create.Subject, ID_Account);
                return Page();
            }
            else
            {
                ViewData["Message"] = "Please enter all data fields";
                return Page();
            }
        }
    }
}
