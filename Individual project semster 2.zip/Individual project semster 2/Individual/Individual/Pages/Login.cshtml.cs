using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BLL.Managers;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using BLL.Domains;

namespace PL.Pages
{
    //allows guest not logged in to be able to access page.(check program.cs if you want to know how the authentication works)
    [AllowAnonymous]
    public class LoginModel : PageModel
    {
        [BindProperty]
        public string Username { get; set; }
        [BindProperty]
        public string Password { get; set; }

        public void OnGet()
        {
            //log out
            HttpContext.SignOutAsync();

        }

        public IActionResult? OnPost()
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "";
                return null;
            }

            Account acc = Accountmanager.check_password(Username, Password);
            if (acc == null)
            {
                ViewData["Message"] = "Invalid Username or Password";
                return null;
            }
            //this is used to set the user as logged in/validated on the browser
            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim("id", acc.Username));
            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            ClaimsPrincipal claimsPrincipal = new ClaimsPrincipal(claimsIdentity);
            HttpContext.SignInAsync(claimsPrincipal);

            return Redirect(String.Format("Index"));
        }

    }
}
