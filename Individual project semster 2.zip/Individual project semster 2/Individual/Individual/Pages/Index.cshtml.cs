﻿using Individual.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using PL.Models;


namespace Individual.Pages
{
    public class IndexModel : BasePage
    {
    }
}