using BLL.Managers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static System.Net.Mime.MediaTypeNames;

namespace PL.Pages
{
    //allows guest not logged in to be able to access page.(check program.cs if you want to know how the authentication works)
    [AllowAnonymous]
    public class Add_AccountModel : PageModel
    {

        [BindProperty]
        public String username { get; set; }
        [BindProperty]
        public String password { get; set; }
        [BindProperty]
        public String passwordcheck { get; set; }
        public IActionResult OnPost()
        {
            if (password != passwordcheck)
            {
                ViewData["Message"] = "password and password check are not the same";
                return Page();
            }
            if (ModelState.IsValid)
            {
                string message = "The User:  " + username + " has been created";
                ViewData["Message"] = message;

                Accountmanager.add(username, password, false, "null");
                return Redirect(String.Format("Login"));
            }
            else
            {
                ViewData["Message"] = "Please enter all data fields";
                return Page();
            }
        }
    }
}
