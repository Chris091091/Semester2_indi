﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
	public static class Question
	{

        public static bool get(string id, IRecord record)
        {
            try
            {
                using (SqlConnection con = DB.Con())
                {
                    // so the interface connects with the quewstion domain in the BAL that is used in the manager which overides the set in the interface with the one in the domain
                    string sql = "Select [ID], [Title], [Text], [Timestamp], [ID_Account] From dbo.Questions Where ID = @ID;";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@ID", id);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        //set will send the data to the interface to the record
                        record.set(dr);
                        return true;
                    }
                }
            }
            catch (SqlException e)
            {
            }
            return false;
        }


        public static bool getAll(IRecordList list)
        {
            try
            {
                using (SqlConnection con = DB.Con())
                {
                    string sql = "Select [ID], [Title], [Text], [Timestamp], [ID_Account] From dbo.Questions;";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        list.AddIRecord().set(dr);
                    }
                    return true;
                }
            }
            catch (SqlException e)
            {
            }
            return false;
        }
        public static bool add(IRecord record)
        {
            try
            {
                using (SqlConnection con = DB.Con())
                {
                    string sql = "Insert into dbo.Questions([ID], [Title], [Text], [Timestamp], [ID_Account]) Values(@ID, @Title, @Text, @Timestamp, @ID_ACCOUNT);";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    record.get(cmd);
                    cmd.ExecuteNonQuery();
                }
                return true;
            }
            catch (SqlException e)
            {
            }
            return false;
        }
        public static bool update(IRecord record)
        {
            try
            {
                using (SqlConnection con = DB.Con())
                {
                    string sql = "Update dbo.Questions Set [Title] = @Title, [Text]= @Text Where [ID] = @ID;";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    record.get(cmd);
                    cmd.ExecuteNonQuery();
                }
                return true;
            }
            catch (SqlException e)
            {
            }
            return false;
        }

        public static bool Delete(IRecord record)
        {
            try
            {
                using (SqlConnection con = DB.Con())
                {
                    string sql = "Delete From dbo.Questions Where [ID] = @ID;";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    record.get(cmd);
                    cmd.ExecuteNonQuery();
                }
                return true;
            }
            catch (SqlException e)
            {
            }
            return false;
        }
    }
}
