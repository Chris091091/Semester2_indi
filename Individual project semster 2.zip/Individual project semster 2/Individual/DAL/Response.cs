﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public static class Response
    {
        public static bool get(string id, IRecord record)
        {
            try
            {
                using (SqlConnection con = DB.Con())
                {
                    string sql = "Select [ID_Response], [Title], [Text], [ID_Question], [Timestamp], [ID_Account] From dbo.Response Where ID_Response = @ID_Response;";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@ID_Response", id);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        record.set(dr);
                        return true;
                    }
                }
            }
            catch (SqlException e)
            {
            }
            return false;
        }

        public static bool getAll(string question_id, IRecordList list)
        {
            try
            {
                using (SqlConnection con = DB.Con())
                {
                    string sql = "Select * From dbo.Response Where ID_Question = @ID_QUESTION;";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@ID_QUESTION", question_id);
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        list.AddIRecord().set(dr);
                    }
                    return true;
                }
            }
            catch (SqlException e)
            {
            }
            return false;
        }
        public static bool add(IRecord record)
        {
            try
            {
                using (SqlConnection con = DB.Con())
                {
                    string sql = "Insert into dbo.Response([ID_Response], [Title], [Text], [Timestamp], [ID_Question], [ID_Account]) Values(@ID_Response, @Title, @Text, @Timestamp, @ID_QUESTION, @ID_ACCOUNT);";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    record.get(cmd);
                    cmd.ExecuteNonQuery();
                }
                return true;
            }
            catch (SqlException e)
            {
            }
            return false;
        }
        public static bool Delete(IRecord record)
        {
            try
            {
                using (SqlConnection con = DB.Con())
                {
                    string sql = "Delete From dbo.Response Where [ID_Response] = @ID_Response;";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    record.get(cmd);
                    cmd.ExecuteNonQuery();
                }
                return true;
            }
            catch (SqlException e)
            {
            }
            return false;
        }

        public static bool update(IRecord record)
        {
            try
            {
                using (SqlConnection con = DB.Con())
                {
                    string sql = "Update dbo.Response Set [Title] = @Title, [Text]= @Text Where [ID_Response] = @ID_Response;";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    record.get(cmd);
                    cmd.ExecuteNonQuery();
                }
                return true;
            }
            catch (SqlException e)
            {
            }
            return false;
        }
    }
}
