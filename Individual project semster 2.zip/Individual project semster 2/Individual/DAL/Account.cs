﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public static class Account
    {
        //public static Account? get(string Username)
        //{
        //    try
        //    {
        //        using (SqlConnection con = DB.Con())
        //        {
        //            string sql = "Select [Username], [Password], [Picture], [Is_Admin], [Is_Blocked] From dbo.Account Where Username = @Username;";
        //            SqlCommand cmd = new SqlCommand(sql, con);
        //            cmd.Parameters.AddWithValue("@Username", Username);
        //            SqlDataReader dr = cmd.ExecuteReader();
        //            Account question = new Account();
        //            if (dr.Read())
        //            {
        //                return new Account(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), (bool)dr[3], (bool)dr[4]);
        //            }
        //        }
        //    }
        //    catch(Exception e)
        //    {
        //    }
        //    return null;
        //}

        public static bool get(string Username, IRecord record)
        {
            try
            {
                using (SqlConnection con = DB.Con())
                {
                    string sql = "Select [Username], [Password], [Is_Admin], [Is_Blocked] From dbo.Account Where Username = @Username;";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@Username", Username);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        record.set(dr);
                        return true;
                    }
                }
            }
            catch (Exception e)
            {
            }
            return false;
        }

        //change this to interface
        public static bool add(IRecord record)
        {
            try
            {
                using (SqlConnection con = DB.Con())
                {
                    string sql = "Insert into dbo.Account([Username], [Password], [Is_Admin], [Is_Blocked]) Values(@Username, @Password, @Is_Admin, 0);";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    record.get(cmd);

                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (Exception e)
            {
            }
            return false;
        }

        public static bool change_password(string username, string password)
        {
            try
            {
                using (SqlConnection con = DB.Con())
                {
                    string sql = "Update dbo.Account Set [Password] = @Password where Username = @Username;";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);

                    cmd.ExecuteNonQuery();
                    return true;
                }
            }


            catch (Exception e)
            {
            }
            return false;
        }
    }
}
