﻿using Microsoft.Data.SqlClient;
namespace DAL
{
    internal static class DB
    {
        internal static SqlConnection Con()
        {
            //Easy to edit 
            SqlConnection con = new SqlConnection(@"Server=mssqlstud.fhict.local;Database=dbi500550_test;User Id=dbi500550_test;Password=Student;TrustServerCertificate=True;");
            con.Open();
            return con;
        }

    }
}