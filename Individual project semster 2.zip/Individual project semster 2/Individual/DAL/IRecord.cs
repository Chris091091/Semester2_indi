﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public interface IRecord
    {
        //SQL dataReader is to get the data
        public void set(SqlDataReader record);
        //SQL command is to add the data
        public void get(SqlCommand record);
    }
}
