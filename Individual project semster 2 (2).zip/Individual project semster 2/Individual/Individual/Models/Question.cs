﻿using Microsoft.Data.SqlClient;

    public partial class DB
    {
        public class Question
        {
            public string id { get; set; }
            public string title { get; set; }
            public string text { get; set; }
            public int votes { get; set; }
            public Question()
            {

            }
            public Question(string ID, string title, string Text, int Votes)
            {
                this.id = ID;
                this.title = title;
                this.text = Text;
                this.votes = Votes;
            }
            public static Question get(int id)
            {
                using (SqlConnection con = Con())
                {
                    string sql = "Select [ID], [Title], [Text], [Votes] From dbo.Questions Where ID = @ID;";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@ID", id);
                    SqlDataReader dr = cmd.ExecuteReader();
                    Question question = new Question();
                    if (dr.Read())
                    {
                        return new Question(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), Convert.ToInt32(dr[3]));
                    }
                    return null;
                }
            }
            public static List<Question> getAll()
            {
                using (SqlConnection con = Con())
                {
                    string sql = "Select [ID], [Title], [Text], [Votes] From dbo.Questions;";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    SqlDataReader dr = cmd.ExecuteReader();
                    List<Question> list = new List<Question>();
                    while (dr.Read())
                    {
                        list.Add(new Question(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), Convert.ToInt32(dr[3])));
                    }
                    return list;
                }
            }
            public static void add(string title, string subject)
            {
                SqlConnection con = new SqlConnection(@"Server=mssqlstud.fhict.local;Database=dbi500550_test;User Id=dbi500550_test;Password=Student;TrustServerCertificate=True;");
                con.Open();
                string sql = "Insert into dbo.Questions([ID], [Title], [Text], [Votes]) Values(@ID, @Title, @Text, 0);";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@Title", title);
                cmd.Parameters.AddWithValue("@Text", subject);
                //temp will add ID system in the future
                Random rnd = new Random();
                cmd.Parameters.AddWithValue("@ID", rnd.Next(1, 100));
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (SqlException e)
                {
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
