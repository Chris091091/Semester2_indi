﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;

namespace Individual.Models
{
    public class Lookup
    {
        public String id;
    }
}
