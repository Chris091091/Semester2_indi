using Individual.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Individual.Pages
{
    public class Create_QuestionModel : PageModel
    {
        [BindProperty]
        public Create create { get; set; }
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                string message = "The Question:  " + create.Title + " has been created";
                ViewData["Message"] = message;
                DB.Question.add(create.Title, create.Subject);
                return Page();
            }
            else
            {
                ViewData["Message"] = "Please enter all data fields";
                return Page();
            }
        }
    }
}
